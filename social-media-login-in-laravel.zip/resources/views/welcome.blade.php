<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <title>Laravel</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap-grid.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap-reboot.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap-utilities.rtl.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/custom.css') }}">
    <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">


</head>

<body class="antialiased">
    <div class="container-fluid text-white px-2 py-2 mt-1 main-bar">
        <div class="container">
            <div class="row">
                <div class="col-md-5 text-center">
                    <a href="https://api.whatsapp.com/send/?phone=%2B919766964045&text=hello&app_absent=0"
                        style="text-decoration: none"> <i class="bi bi-whatsapp"> +91.9766964045</i></a>

                    <i class="bi bi-envelope"> amolkhote333@gmail.com</i>
                </div><br>
                <div class="col-md-4 offset-md-3 text-center main-icon">
                    <a href="https://www.instagram.com/smartlook_clothing" target="_blank"><i
                            class="bi bi-instagram"></i></a>
                    <a href="https://www.facebook.com/SmartLookMensFashion" target="_blank"><i
                            class="bi bi-facebook"></i></a>
                    <a href="https://api.whatsapp.com/send/?phone=%2B919766964045&text=hello&app_absent=0"
                        target="_blank"><i class="bi bi-whatsapp"></i></a>
                    <a href="#" target="_blank"><i class="bi bi-twitter"></i></a>
                </div>
            </div>
        </div>
    </div>



        <div class="container-fluid bg-light marquee">
            <marquee behavior="scroll" direction="left" style=" margin-top: 10px;"><span
                    style="font-size: 30px">20%</span> <span class="text-capitalize">ON PAID WEBSITE
                    TEMPLATES</span></marquee>
        </div>



    <nav class="navbar navbar-expand-lg navbar-light bg-light px-2 py-2 ">
        <div class="container-fluid">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 offset-md-4 text-center">
                        <a class="navbar-brand px-2 py-2" href="{{ url('index') }}">Smart Look Mens Fashion</a>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row my-auto">
                    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbar"
                        style="position: static">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="col-md-8 offset-md-4">
                        <div class=" collapse navbar-collapse custom-navbar" id="navbar">
                            <ul class="navbar-nav text-center">
                                <li class="nav-item active">
                                    <a class="nav-link " href="{{ url('/index') }}" style="color: red">Home </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Free</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Paid</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink"
                                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        Account
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-lg-right"
                                        aria-labelledby="navbarDarkDropdownMenuLink">
                                        <li><a class="dropdown-item" data-toggle="modal" href="javascript:void(0)" onclick="openLoginModal();">Login</a></li>
                                        <li><a class="dropdown-item" data-toggle="modal" href="javascript:void(0)" onclick="openRegisterModal();">Register</a></li>
                                        {{-- <li><a class="dropdown-item" href="#">Something else here</a></li> --}}
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>



    <div class="container mt-lg-5">
        <div class="row">
            <div class="col-md-3 card mt-md-5">

                <img class="card-img-top card-zoom" src="{{ asset('image/template_image/t1.jpg') }}"
                    alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                        the card's content.</p>
                    <a href="#" class="btn btn-primary">Demo</a>
                    <a href="{{ url('/zip') }}" class="btn btn-danger">Download</a>
                </div>

            </div>
            <div class="col-md-3 card mt-md-5">
                <img class="card-img-top card-zoom" src="{{ asset('image/template_image/t1.jpg') }}"
                    alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                        the card's content.</p>
                    <a href="#" class="btn btn-primary">Demo</a>
                    <a href="#" class="btn btn-danger">Download</a>
                </div>
            </div>
            <div class="col-md-3 card mt-md-5">
                <img class="card-img-top card-zoom" src="{{ asset('image/template_image/t1.jpg') }}"
                    alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                        the card's content.</p>
                    <a href="#" class="btn btn-primary">Demo</a>
                    <a href="#" class="btn btn-danger">Download</a>
                </div>
            </div>
            <div class="col-md-3 card mt-md-5">
                <img class="card-img-top card-zoom" src="{{ asset('image/template_image/t1.jpg') }}"
                    alt="Card image cap">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                        the card's content.</p>
                    <a href="#" class="btn btn-primary">Demo</a>
                    <a href="#" class="btn btn-danger">Download</a>
                </div>
            </div>
        </div>
    </div>

 {{-- Login Page --}}
 <div class="modal fade login" id="loginModal">
    <div class="modal-dialog login animated">
        <div class="modal-content">
           <div class="modal-header">
               <h4 class="modal-title">Login with</h4>
               <button type="button" class="close" data-dismiss="loginModal" aria-hidden="true">&times;</button>
          </div>
          <div class="modal-body">
              <div class="box">
                   <div class="content">
                    <div class="social">
                        <a class="circle github" href="#">
                            <i class="fa fa-github fa-fw"></i>
                        </a>
                        <a id="google_login" class="circle google" href="{{ route('login.google') }}">
                            <i class="fa fa-google-plus fa-fw"></i>
                        </a>
                        <a id="facebook_login" class="circle facebook" href="{{ route('login.facebook') }}">
                            <i class="fa fa-facebook fa-fw"></i>
                        </a>
                    </div>
                      <div class="division">
                          <div class="line l"></div>
                            <span>or</span>
                          <div class="line r"></div>
                      </div>
                      <div class="error"></div>
                      <div class="form loginBox">
                          <form method="" action="" accept-charset="UTF-8">
                          <input id="email" class="form-control" type="text" placeholder="Email" name="email">
                          <input id="password" class="form-control" type="password" placeholder="Password" name="password">
                          <input class="btn btn-default btn-login" type="button" value="Login" onclick="loginAjax()">
                          </form>
                      </div>
                   </div>
              </div>
              <div class="box">
                  <div class="content registerBox" style="display:none;">
                   <div class="form">
                      <form method="" html="{:multipart=>true}" data-remote="true" action="" accept-charset="UTF-8">
                      <input id="email" class="form-control" type="text" placeholder="Email" name="email">
                      <input id="password" class="form-control" type="password" placeholder="Password" name="password">
                      <input id="password_confirmation" class="form-control" type="password" placeholder="Repeat Password" name="password_confirmation">
                      <input class="btn btn-default btn-register" type="button" value="Create account" name="commit">
                      </form>
                      </div>
                  </div>
              </div>
          </div>
          <div class="modal-footer">
              <div class="forgot login-footer">
                  <span>Looking to
                       <a href="javascript: showRegisterForm();">create an account</a>
                  ?</span>
              </div>
              <div class="forgot register-footer" style="display:none">
                   <span>Already have an account?</span>
                   <a href="javascript: showLoginForm();">Login</a>
              </div>
          </div>
        </div>
    </div>
</div>
</div>
 {{-- End Of Login Page --}}

 <script type="text/javascript">
    $(document).ready(function(){
        openLoginModal();
    });

</script>


    <script src="{{ asset('js/jQuery.js') }}"></script>
    <script src="{{ asset('js/bootstrap.bundle.js') }}"></script>
    <script src="{{ asset('js/bootstrap.esm.js') }}"></script>
    <script src="{{ asset('js/bootstrap.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/custom.js') }}"></script>

    {{-- <script>
        $('.navbar-collapse a').click(function() {
            $(".navbar-collapse").collapse('hide');
        });
    </script> --}}
</body>


</html>
