<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;

use App\Models\Users;
use App\Providers\RouteServiceProvider;
use CreateUsersTable;
use Illuminate\Contracts\Session\Session;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Laravel\Socialite\Facades\Socialite;
use PhpParser\Node\Stmt\TryCatch;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    // FUnction For Check Email Is Exits Or Not
    public function IsExits($email)
    {
        $data = DB::select('select * from users where email = ?', [$email]);
        if (count($data) == 0) {
            return 0;
        } else {
            return 1;
        }
    }


    public function logout(Request $request)
    {
        $request->session()->flash('user');
        // Session::forget(config('user'));

        $request->session()->flush();

        $request->session()->regenerate();
        return redirect('/login');
    }
    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    // Function For Google
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }
    // Function For Google Callback
    public function handleGoogleCallback(Request $request)
    {
        $user = Socialite::driver('google')->stateless()->user();
        if ($this->IsExits($user->email)) {
            $request->session()->put('user', $user->email);
            $request->session()->put('image', $user->avatar);

            return redirect()->route('home'); //Return Lohin Page
        } else {
            $check = Users::create([
                'google_id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'image' => $user->avatar,
            ]);
            if ($check) {
                $request->session()->put('user', $user->email);
                $request->session()->put('image', $user->avatar);
                // Auth::login($user);::login($user);
                return redirect()->route('home');
            } else {
                dd('not okk');
            }
        }

    }

    // Function For facebook
    public function redirectToFacebook()
    {
        return Socialite::driver('facebook')->redirect();
    }
    // Function For Facebook Callback
    public function handleFacebookCallback(Request $request)
    {

        $user = Socialite::driver('facebook')->stateless()->user();
$fb_id = $user->id;
        if ($this->IsExits($user->email)) {
            $request->session()->put('user', $user->email);
            $request->session()->put('image', $user->avatar_original);

            return redirect()->route('home'); //Return Lohin Page
        } else {
            $check = Users::create([
                'facebook_id' => $fb_id,
                'name' => $user->name,
                'email' => $user->email,
                'image' => $user->avatar_original,
            ]);
            if ($check) {
                $request->session()->put('user', $user->email);
                $request->session()->put('image', $user->avatar_original);
                // Auth::login($user);::login($user);
                return redirect()->route('home');
            } else {
                dd('not okk');
            }
        }
    }
}
