<?php

namespace App\Http\Controllers;

use Dotenv\Store\FileStore;
// use Facade\FlareClient\Stacktrace\File;
use Illuminate\Http\Request;
use ZipArchive;
use File;

class ZipController extends Controller
{
    //Function For Zip File
    public function zipFile()
    {
        $zip = new ZipArchive;
        $filename = 'Template.zip';
        if ($zip->open(public_path($filename), ZipArchive::CREATE) === TRUE) {
            $filePath  =public_path('/');
            $files = File::files(public_path('project/', GLOB_ERR, []));
            foreach ($files as $key => $value) {





                $relativeNameInZipFile = basename($value);
                $zip->addFile($value, $relativeNameInZipFile);
            }
            // $zip->addEmptyDir('css');
            // $zip->addEmptyDir('js');
            $zip->close();
        }
        return response()->download(public_path($filename));

    }
}
