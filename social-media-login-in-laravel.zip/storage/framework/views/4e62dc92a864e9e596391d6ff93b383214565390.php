<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(Session::get('user')); ?></div>




                <img src="<?php echo e(Session::get('image')); ?>" alt="profile photo" width="50px" height="50px">
<br>


                

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
        <a href="<?php echo e(route('logout')); ?>">Logout</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\My_Project\resources\views/home.blade.php ENDPATH**/ ?>