<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;
use Laravel\Socialite\Facades\Socialite;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ZipController;
use Illuminate\Support\Facades\DB;

// Route For Main Page
Route::get('/main', function () {
    return view('main');
});

Route::get('/index', function () {
    $data = DB::select('select offer_per,active from offer where active =?', [1]);

foreach($data as $data1){
    $offer_per =$data1->offer_per;
    $offer_active= $data1->active;
}

    return view('welcome',array('offer_per'=>$offer_per,'offer_active'=>$offer_active));
});

Auth::routes();

Route::get('/home', function(){
    return view('home');
})->name('home');


Route::get('logout', [LoginController::class, 'logout'])->name('logout');

// Google Login

Route::get('login/google', [LoginController::class,'redirectToGoogle'])->name('login.google');
Route::get('login/google/callback', [LoginController::class,'handleGoogleCallback']);






// FaceBook Login

Route::get('login/facebook', [LoginController::class,'redirectToFacebook'])->name('login.facebook');
Route::get('login/facebook/callback', [LoginController::class,'handleFacebookCallback']);

// Github Login


Route::get('login/github', [LoginController::class,'redirectToGithub'])->name('login.github');
Route::get('login/github/callback', [LoginController::class,'handleGithubCallback']);



// Route For Download Zip File
Route::get('/zip',[ZipController::class,'zipFile']);

Route::get('/demo',function(){
   return view('demo');
});
// route for clear all cache data
Route::get('/cache_data', function () {
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('view:clear');
    Artisan::call('event:clear');
    Artisan::call('route:clear');
    return "Cache is cleared";
});

